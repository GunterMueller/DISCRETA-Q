#include <stdlib.h>

int main(void)
{
  system("wish ../../sources/tcltk/discreta_q.tcl");
  return 0;
}


