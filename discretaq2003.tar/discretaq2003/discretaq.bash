export discretaq_path=`pwd`

export PATH=$PATH:$discretaq_path"/bin"


